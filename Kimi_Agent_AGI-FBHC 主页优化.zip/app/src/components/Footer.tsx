import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Github, Globe, Mail, ExternalLink } from 'lucide-react';

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
};

export default function Footer() {
  return (
    <footer
      className="border-t border-[rgba(255,255,255,0.06)]"
      style={{ background: '#0A0A12' }}
    >
      <div className="mx-auto max-w-7xl px-4 pt-16 pb-8 sm:px-6 lg:px-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4"
        >
          {/* Column 1: Brand */}
          <motion.div variants={itemVariants}>
            <div className="flex items-center gap-2.5">
              <div className="flex items-center justify-center rounded-xl bg-white/90 p-1">
                <img src="./logo.png" alt="AGI&FBHC" className="h-5 w-5 object-contain" />
              </div>
              <span className="text-sm font-semibold tracking-wide text-[#F0F0F5]">
                AGI&FBHC
              </span>
            </div>
            <p className="mt-3 text-xs text-[#55556B]">
              通用人工智能&食品生物健康交叉研究中心
            </p>
            <p className="mt-1 text-xs text-[#55556B]">
              江南大学 · 江苏省 333 人才 · 教育部科技进步一等奖
            </p>
            <p className="mt-2 text-xs text-[#55556B]">
              Advancing AI for Agents, Biology, and Health.
            </p>
          </motion.div>

          {/* Column 2: Research Groups */}
          <motion.div variants={itemVariants}>
            <h4 className="mb-4 text-sm font-semibold text-[#F0F0F5]">Research Groups</h4>
            <div className="flex flex-col gap-2.5">
              <Link
                to="/groups/llm-agent"
                className="text-sm text-[#8B8B9E] transition-colors hover:text-[#F0F0F5]"
              >
                大模型与智能体
              </Link>
              <Link
                to="/groups/ai-for-biology"
                className="text-sm text-[#8B8B9E] transition-colors hover:text-[#F0F0F5]"
              >
                AI for Biology
              </Link>
              <Link
                to="/groups/ai-for-health"
                className="text-sm text-[#8B8B9E] transition-colors hover:text-[#F0F0F5]"
              >
                AI for Health
              </Link>
            </div>
          </motion.div>

          {/* Column 3: Platforms & Links */}
          <motion.div variants={itemVariants}>
            <h4 className="mb-4 text-sm font-semibold text-[#F0F0F5]">Platforms</h4>
            <div className="flex flex-col gap-2.5">
              <a
                href="https://research.agi-fbhc.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-[#8B8B9E] transition-colors hover:text-[#F0F0F5]"
              >
                Research Platform
                <ExternalLink className="h-2.5 w-2.5" />
              </a>
              <a
                href="https://email.agi-fbhc.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-[#8B8B9E] transition-colors hover:text-[#F0F0F5]"
              >
                XClaw Email
                <ExternalLink className="h-2.5 w-2.5" />
              </a>
              <a
                href="https://github.com/AGI-FBHC"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-[#8B8B9E] transition-colors hover:text-[#F0F0F5]"
              >
                GitHub
                <ExternalLink className="h-2.5 w-2.5" />
              </a>
              <a
                href="https://huggingface.co/AGI-FBHC"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-[#8B8B9E] transition-colors hover:text-[#F0F0F5]"
              >
                HuggingFace
                <ExternalLink className="h-2.5 w-2.5" />
              </a>
            </div>
          </motion.div>

          {/* Column 4: Contact */}
          <motion.div variants={itemVariants}>
            <h4 className="mb-4 text-sm font-semibold text-[#F0F0F5]">Contact</h4>
            <div className="flex flex-col gap-2.5">
              <span className="text-sm text-[#8B8B9E]">邓赵红教授</span>
              <a
                href="mailto:dengzhaohong@jiangnan.edu.cn"
                className="text-sm text-[#A5B4FC] transition-colors hover:underline"
              >
                dengzhaohong@jiangnan.edu.cn
              </a>
              <span className="text-sm text-[#55556B]">江南大学</span>
            </div>
            <div className="mt-4 flex items-center gap-3">
              <a
                href="https://github.com/AGI-FBHC"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-9 w-9 items-center justify-center rounded-lg bg-[rgba(255,255,255,0.05)] text-[#8B8B9E] transition-colors hover:bg-[rgba(255,255,255,0.1)]"
                aria-label="GitHub"
              >
                <Github className="h-4 w-4" />
              </a>
              <a
                href="https://huggingface.co/AGI-FBHC"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-9 w-9 items-center justify-center rounded-lg bg-[rgba(255,255,255,0.05)] text-[#8B8B9E] transition-colors hover:bg-[rgba(255,255,255,0.1)]"
                aria-label="HuggingFace"
              >
                <Globe className="h-4 w-4" />
              </a>
              <a
                href="mailto:dengzhaohong@jiangnan.edu.cn"
                className="flex h-9 w-9 items-center justify-center rounded-lg bg-[rgba(255,255,255,0.05)] text-[#8B8B9E] transition-colors hover:bg-[rgba(255,255,255,0.1)]"
                aria-label="Email"
              >
                <Mail className="h-4 w-4" />
              </a>
            </div>
          </motion.div>
        </motion.div>

        {/* Bottom bar */}
        <div className="mt-12 flex flex-col items-center justify-between gap-2 border-t border-[rgba(255,255,255,0.06)] pt-6 md:flex-row">
          <p className="text-xs text-[#55556B]">
            &copy; 2025 AGI&FBHC Research Group. All rights reserved.
          </p>
          <p className="text-xs text-[#55556B]">
            通用人工智能&食品生物健康交叉研究中心 · 江南大学
          </p>
        </div>
      </div>
    </footer>
  );
}
